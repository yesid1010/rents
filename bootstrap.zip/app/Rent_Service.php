<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rent_Service extends Model
{
    //
    public $table = 'rent_service';
}
