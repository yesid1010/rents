<div class="form-group row">
  <label class="col-md-3 form-control-label" for="cliente">Cliente : </label>
  <div class="col-md-5">
      <select class="form-control" name="user_id" id="ex-search">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($user->id); ?>"><?php echo e($user->identification); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
  </div>
</div>

<div class="form-group row">
  <label class="col-md-3 form-control-label" for="cliente">Habitacion : </label>
  <div class="col-md-5">
      <select class="form-control" required name="id" id="ex-search2">
        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($room->id); ?>"><?php echo e($room->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
  </div>
</div>

<div class="form-group row">
  <label class="col-md-3 form-control-label" for="unity">Fecha Inicio : </label>
  <div class="col-md-5">
      <input type="date" name="startdate" id="startdate"  required class="form-control">    
  </div>
</div>
<div class="form-group row">
  <label class="col-md-3 form-control-label" for="unity">Fecha Salida : </label>
  <div class="col-md-5">
      <input type="date" name="endingdate" id="endingdate"  required class="form-control">    
  </div>
</div>
<div class="form-group row">
  <label class="col-md-3 form-control-label" for="unity">Descripcion : </label>
  <div class="col-md-5">
    <textarea  name="description" id="description" required rows ="2" class="form-control" placeholder="Ingrese descripcion"></textarea>
  </div>
</div>

<div class="modal-footer">
  <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Cerrar</button>
  <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Guardar</button> 
</div>




<?php /**PATH C:\xampp\htdocs\hab\resources\views/rents/form.blade.php ENDPATH**/ ?>