<?php $__env->startSection('content'); ?>
<div class="container"> 
    <div class="row">
      <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary">
                    <strong>Información del cliente</strong> 
                 </div>
                <div class="card-body">
                    <div class=" row">
                        <label class="col-md-6 form-control-label" for="unity">Identificacion :</label>
                        <label class="col-md-6 form-control-label" for="unity"><?php echo e($user->identification); ?></label> 
                    </div>
                    <div class=" row">
                        <label class="col-md-6 form-control-label" for="unity">Nombres :</label>
                        <label class="col-md-6 form-control-label" for="unity"><?php echo e($user->nameUser); ?></label> 
                    </div>
                    <div class=" row">
                        <label class="col-md-6 form-control-label" for="unity">Correo :</label>
                        <label class="col-md-6 form-control-label" for="unity"><?php echo e($user->email); ?></label> 
                    </div>
                    <div class=" row">
                        <label class="col-md-6 form-control-label" for="unity">Telefono :</label>
                        <label class="col-md-6 form-control-label" for="unity"><?php echo e($user->telephone); ?></label> 
                    </div>
                    <div class=" row">
                        <label class="col-md-6 form-control-label" for="unity">Contacto familiar:</label>
                        <label class="col-md-6 form-control-label" for="unity"><?php echo e($user->family_telephone); ?></label> 
                    </div>

                </div>
            </div>
      </div>
      <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary">
                    <strong>Información del Arriendo</strong> 
                 </div>
                <div class="card-body">
                    <div class=" row">
                        <label class="col-md-6 form-control-label" for="unity">Fecha Entrada:</label>
                        <label class="col-md-6 form-control-label" for="unity"><?php echo e($rent->startdate); ?></label> 
                    </div>
                    <div class=" row">
                        <label class="col-md-6 form-control-label" for="unity">Fecha Salida:</label>
                        <label class="col-md-6 form-control-label" for="unity"><?php echo e($rent->endingdate); ?></label> 
                    </div>
                    <div class=" row">
                        <label class="col-md-6 form-control-label" for="unity">Huela Dactilar:</label>
                        <label class="col-md-6 form-control-label" for="unity"><?php echo e($rent->fingerprint); ?></label> 
                    </div>
                    <div class=" row">
                        <label class="col-md-6 form-control-label" for="unity">Habitacion:</label>
                        <label class="col-md-6 form-control-label" for="unity"><?php echo e($room->nameRoom); ?></label> 
                    </div>
                    <div class=" row">
                        <label class="col-md-6 form-control-label" for="unity">Estado:</label>
                        <?php if($rent->statusRent == 0): ?>
                            <label class="col-md-6 form-control-label" for="unity">Pendiente por pagar</label> 
                        <?php else: ?>
                           <label class="col-md-6 form-control-label" for="unity">Pagado</label>
                        <?php endif; ?>
                    </div>
                </div>
            </div> 
        </div>
        
    </div>
    <div class="row mt-5">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary">
                    <strong>Informacion de pago total</strong> 
                </div>
                <div class="card-body">
                    <div class=" row">
                        <label class="col-md-6 form-control-label" for="unity">Precio Habitacion :</label>
                        <label class="col-md-6 form-control-label" for="unity"><?php echo e(number_format($room->priceRoom, 0 )); ?></label> 
                    </div>
                    <hr>
                    <label class="form-control-label">Servicios Adicionales</label>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class=" row">
                            <label class="col-md-6 form-control-label" for="unity"><?php echo e($service->nameService); ?></label>
                            <label class="col-md-6 form-control-label" for="unity"><?php echo e(number_format($service->priceService, 0 )); ?></label> 
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr>
                    <div class=" row">
                        <label class="col-md-6 form-control-label" for="unity">Total a pagar</label>
                        <label class="col-md-6 form-control-label" for="unity"><?php echo e(number_format($total, 0 )); ?></label> 
                    </div>
                </div>
            </div>
        </div>   
    <?php if($rent->statusRent): ?>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-primary">
                    <strong>Informacion del pago </strong> 
                </div>
                <div class="card-body">
                    <div class=" row">
                        <label class="col-md-6 form-control-label" for="unity">Tipo de pago :</label>
                        <label class="col-md-6 form-control-label" for="unity"><?php echo e($payment->type); ?></label> 
                    </div>
                    <div class=" row">
                        <label class="col-md-6 form-control-label" for="unity">Atendido por :</label>
                        <label class="col-md-6 form-control-label" for="unity"><?php echo e($empleado->name); ?></label> 
                    </div>
                </div>
            </div>
        </div>  
    <?php endif; ?> 
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hab\resources\views/rents/show.blade.php ENDPATH**/ ?>