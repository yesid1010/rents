<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Rooms')); ?></title>



        <!-- Icons -->
        <link href="vendors/css/font-awesome.min.css" rel="stylesheet">
        <link href="vendors/css/simple-line-icons.min.css" rel="stylesheet">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    
    <link rel="stylesheet" href="vendors/css/picker.min.css">

    
    <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.css">

</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-primary shadow-sm navbar-fixed-top">
            <div class="container">
                <?php if(Auth::check()): ?>
                    <a class="navbar-brand " href="<?php echo e(url('/rooms')); ?>">
                        Habitaciones
                    </a>
                <?php else: ?> 
                    <a class="navbar-brand" href="<?php echo e(url('/rooms')); ?>">
                        Home
                    </a>
                <?php endif; ?>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                        <?php if(Auth::check()): ?>
                            <li class="nav-item navbar-brand">
                                <a class="nav-link" href="<?php echo e(route('rents.index')); ?>"><?php echo e(__('Arrriendos')); ?></a>
                            </li>
                            <li class="nav-item navbar-brand">
                                <a class="nav-link" href="<?php echo e(route('services.index')); ?>"><?php echo e(__('Servicios')); ?></a>
                            
                            <li class="nav-item navbar-brand">
                                <a class="nav-link" href="<?php echo e(route('users.index')); ?>"><?php echo e(__('Clientes')); ?></a>
                            </li>
                        <?php endif; ?>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><b><?php echo e(__('Login')); ?></b> </a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><b><?php echo e(__('Register')); ?></b> </a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
   
    <!-- scripts -->
            <!-- Bootstrap and necessary plugins -->
            <script src="vendors/js/jquery.min.js"></script>
            <script src="vendors/js/popper.min.js"></script>
            <script src="vendors/js/bootstrap.min.js"></script>
            <script src="vendors/js/pace.min.js"></script>
            <!-- Plugins and scripts required by all views -->
            <script src="vendors/js/Chart.min.js"></script>
            <!-- GenesisUI main scripts -->
            <script src="vendors/js/template.js"></script>
            <!-- DataTables -->
            <script src="plugins/datatables/jquery.dataTables.js"></script>
            <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>

            
            <script type="text/javascript" src="vendors/js/picker.min.js"></script>


    <script src="vendors/js/app.js"></script>
    <script src="<?php echo e(asset('js/modal.js')); ?>" ></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\hab\resources\views/layouts/app.blade.php ENDPATH**/ ?>