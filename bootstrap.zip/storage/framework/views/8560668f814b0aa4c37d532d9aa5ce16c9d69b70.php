

  <div class="form-group row">
    <label class="col-md-3 form-control-label" for="servicios">Servicios : </label>
    <div class="col-md-5">
        <select class="form-control" required name="service_id" id="service_id">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>

<div class="form-group row">
    <label class="col-md-3 form-control-label" for="unity">Descripcion : </label>
    <div class=" col-md-8">
      <textarea required name="description" id="description" rows ="2" class="form-control" placeholder="Ingrese descripcion"></textarea>
    </div>
</div>

<div class="modal-footer">
    <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Cerrar</button>
    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Guardar</button> 
</div><?php /**PATH C:\xampp\htdocs\hab\resources\views/rents/services.blade.php ENDPATH**/ ?>