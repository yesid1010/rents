
<?php /**PATH C:\xampp\htdocs\hab\resources\views/home.blade.php ENDPATH**/ ?>