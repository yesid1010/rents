<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">    <title>Reportes</title>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-6">
            Fecha: <?php echo e($payment->created_at); ?>

        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-md-6">
                Recibido por : <?php echo e($empleado->name); ?>

        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-6">
                Datos del Huésped
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
                Identificación : <?php echo e($huesped->identification); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            Nombre : <?php echo e($huesped->nameUser); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            Telefono : <?php echo e($huesped->telephone); ?>

        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            Correo : <?php echo e($huesped->email); ?>

        </div>
    </div>

    <hr>
    <div class="row">
        <div class="col-md-6">
                Datos del Arriendo
        </div>
    </div>
        <table class="table table-bordered table-striped mt-2">
            <thead>
                <tr>
                    <th>Habitacion</th>
                    <th>Costo</th>
                    <th>Huella</th>
                    <th>Fecha Entrada</th>
                    <th>Fecha Salida</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th><?php echo e($room->nameRoom); ?></th>
                    <th><?php echo e(number_format($room->priceRoom, 0 )); ?></th>
                    <th><?php echo e($rent->fingerprint); ?></th>
                    <th><?php echo e($rent->startdate); ?></th>
                    <th><?php echo e($rent->endingdate); ?></th>
                </tr>
            </tbody>
        </table>
   
<?php if(count($rent_->services) > 0): ?>
    <div class="row">
        <div class="col-md-6 mt-4">
                Servicios Adicionales
        </div>
    </div>
        <table class="table table-bordered table-striped mt-2">
            <thead>
                <tr>
                    <th>Tipo de servicio</th>
                    <th>Costo</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($service->nameService); ?></th>
                        <th><?php echo e(number_format($service->priceService,0)); ?></th>
                    </tr> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
<?php endif; ?> 
        <div class="row">
            <div class="col-md-6 float-right mt-5">
                    Total A Pagar : <?php echo e(number_format($payment->total, 0 )); ?>

            </div>
        </div>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\hab\resources\views/pdf/template.blade.php ENDPATH**/ ?>