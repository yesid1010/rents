<?php $__env->startSection('content'); ?>
<div class="container"> 
    <div class="card">
        <div class="card-header">     
            <h3 class="float-left">Listado de Servicios</h3>       
            <button class="btn btn-primary float-right mt-1" type="button" data-toggle="modal" data-target="#abrirmodalService">
                <i class="fa fa-plus "></i>&nbsp;&nbsp;Agregar Servicio
            </button>
        </div>
    </div>

    <?php if(session('mensajeok')): ?>
        <div class="alert alert-success">
            <?php echo e(session('mensajeok')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="card-body">
        <table id="tablaServicios" class="table table-bordered table-striped">
            <thead class="bg-primary">
                <tr>
                    <th>Nombre</th>
                    <th>precio</th>
                    <th>Descripción</th>
                    <th>Editar</th>  
                    <th>Eliminar</th> 
                </tr>
            </thead>

            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($service->name); ?></td>
                <td><?php echo e($service->price); ?></td>
                <td><?php echo e($service->description); ?></td>
                <td class="text-center"> <button class="btn btn-primary" type="button"
                        data-target="#abrirmodalEditarService"
                        data-toggle="modal" 
                        data-id="<?php echo e($service->id); ?>"
                        data-name="<?php echo e($service->name); ?>"
                        data-price="<?php echo e($service->price); ?>"
                        data-description="<?php echo e($service->description); ?>">  
                        Editar
                    </button>
                </td>
                <td class="text-center">
                    <button class="btn btn-danger " data-id="<?php echo e($service->id); ?>" type="button" data-toggle="modal" data-target="#abrirmodalEliminarService">
                            <i class="fa fa-trash-o" aria-hidden="true"></i>
                    </button>
                </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>

<!--- MODALES --->
<!--Inicio del modal agregar-->
<div class="modal fade" id="abrirmodalService" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-primary" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Agregar Servicio</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            
            <div class="modal-body">
                <form action="<?php echo e(route('services.store')); ?>" method="post" class="form-horizontal">
                    <?php echo e(csrf_field()); ?>

                    <?php echo $__env->make('services.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </form>
            </div>

        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!--Fin del modal agregar Service-->

<!--Inicio del modal editar-->
<div class="modal fade" id="abrirmodalEditarService" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-primary" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Editar Servicio</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            
            <div class="modal-body">
                <form action="<?php echo e(route('services.update','test')); ?>" method="post" class="form-horizontal">
                    <?php echo e(method_field('patch')); ?>

                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="id" id="id" value="">
                    <?php echo $__env->make('services.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </form>
            </div>

        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!--Fin del modal editar service-->

<!--Inicio del modal de eliminar-->
<div class="modal fade" id="abrirmodalEliminarService" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-primary " role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h4 class="modal-title">¿ Está seguro de realizar esta acción?</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            
            <div class="modal-body">
                <h5>Al dar click en Aceptar, No se podrá deshacer esta acción.</h5>
                <form action="<?php echo e(route('destroyservice')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>   
                    <input type="hidden" name="id" id="id" value="">  
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Cancelar</button>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Aceptar</button> 
                    </div>
                </form>
            </div>

        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!--Fin del modal-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hab\resources\views/services/index.blade.php ENDPATH**/ ?>